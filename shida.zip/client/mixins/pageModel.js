/**
 * 针对页面的一些操作方法
 * */
export default {
  methods: {
    savePage() {},
    publishPage() {}
  }
};
