export default {
  data() {
    return {
      canvasWidth: 0,
      canvasHeight: 0,
    };
  },
};
