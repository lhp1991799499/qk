<template>
  <div>
    <div v-for="item in templateArr" :key="item.name">
      <div class="flex-item">
        <div class="title">节气外框</div>
        <div class="more">more</div>
      </div>
      <div class="imgs-container">
        <div v-for="i in item.items" :key="i.img">
          <div class="img-box" @click="handleClick(i)"></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
// import editorProjectConfig from "@/pages/editor/DataModel";
import editor from "@client/mixins/editor.js";

export default {
  mixins: [editor],
  data() {
    return {
      templateArr: [
        {
          id: "",
          name: "节气",
          items: [
            {
              elName: "qk-text",
              title: "文字",
              icon: "iconfont iconwenben",
              // 每个组件设置props来展示哪些显示哪些编辑项
              valueType: "", // 标识数据类型，用于表单组件
              defaultStyle: {
                height: 40,
              },
            },
            {
              img: "1",
            },
            {
              img: "2",
            },
          ],
        },
      ],
    };
  },
  async created() {
    // await this.newPage();
    // this.$store.dispatch("setPrjectData");
  },
  computed: {
    ...mapState({
      // projectData: (state) => state.editor.projectData,
      // activePageUUID: (state) => state.editor.activePageUUID,
      // activeElementUUID: (state) => state.editor.activeElementUUID,
    }),
  },
  methods: {
    // // 新建页面
    // async newPage(isTemplate) {
    //   let newPageData = editorProjectConfig.getProjectConfig();
    //   this.$API
    //     .createPage({ ...newPageData })
    //     .then((res) => {
    //       if (res.body) {
    //         console.log(res.body);
    //         let id = res.body._id;
    //         this.initPageData(id);
    //       }
    //     })
    //     .catch(() => {
    //       this.loading = false;
    //     });
    // },
    // /**
    //  * 初始化页面数据
    //  */
    // async initPageData(id) {
    //   console.log(this.id);
    //   // this.loading = true;
    //   this.$API
    //     .getPageDetail({ pageId: id })
    //     .then((res) => {
    //       // this.loading = false;
    //       this.$store.dispatch("setPrjectData", {
    //         ...res.body,
    //       });
    //     })
    //     .catch(() => {
    //       // this.loading = false;
    //     });
    // },
  },
};
</script>
<style lang="scss" scoped>
.more {
  cursor: pointer;
  font-weight: 400;
  color: #999999;
}
.flex-item {
  display: flex;
  justify-content: space-between;
  margin-bottom: 12px;
  margin-top: 12px;
}
.title {
  font-size: 13px;
  font-weight: bold;
  color: #333333;
}
.img-box {
  width: 82px;
  height: 82px;
  background: greenyellow;
  border-radius: 4px;
}
.imgs-container {
  display: flex;
  justify-content: space-between;
}
</style>
