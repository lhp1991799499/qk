<template>
  <div class="edit-panel-container">
    <el-tabs type="border-card" stretch>
      <el-tab-pane label="字体">
        <span slot="label"><i class="el-icon-date"></i> 字体</span>
        <edit-panel-font />
      </el-tab-pane>
      <el-tab-pane label="动画">
        <edit-panel-animation />
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import editPanelFont from "./edit-panel/edit-panel-font.vue";
import editPanelAnimation from "./edit-panel/edit-panel-animation.vue";
export default {
  components: {
    editPanelFont,
    editPanelAnimation,
  },
};
</script>
<style lang="scss" scoped>
/deep/ .el-tabs {
  height: 100%;
}
.edit-panel-container {
  min-width: 320px;
  box-sizing: border-box;
  box-shadow: 2px 0px 6px 0px rgba(0, 21, 41, 0.12);
  background: gainsboro;
}
</style>
