<template>
  <div class="container" style="display: block">
    <el-input
      placeholder="音乐"
      v-model="input"
      clearable
      prefix-icon="el-icon-search"
      clear="onClearChange"
    >
    </el-input>
    <div class="music-list">
      <div
        v-for="item in listAudios"
        :key="item.id"
        :class="`${item.using ? 'item-using' : ''} music-item`"
      >
        <div class="music-item-left">
          <div>
            <div class="music-left-icon"></div>
          </div>
          <div class="music-item-left-r">
            <div class="name">{{ item.name }}</div>
            <div class="music-item-left-name">
              <div class="singer">{{ item.singer }}</div>
              <div class="timer">{{ item.timer }}秒</div>
            </div>
          </div>
        </div>
        <div class="using">
          {{ item.using ? "使用中" : "" }}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import scrollTabs from "../scroll-tabs.vue";
import templateContainer from "../template-container.vue";
import editor from "@client/mixins/editor.js";

export default {
  mixins: [editor],
  components: {
    scrollTabs,
    templateContainer,
  },
  data() {
    return {
      input: "",
      item: {
        elName: "qk-text",
        title: "文字",
        icon: "iconfont iconwenben",
        // 每个组件设置props来展示哪些显示哪些编辑项
        valueType: "", // 标识数据类型，用于表单组件
        defaultStyle: {
          // height: 40,
        },
      },
      listAudios: [
        {
          id: "",
          icon: "img",
          name: "稻香",
          singer: "jay-zhou",
          timer: "3",
          using: true,
        },
        {
          id: "2",
          icon: "img3",
          name: "稻香2",
          singer: "jay-zhou2",
          timer: "33",
          using: false,
        },
      ],
    };
  },
  methods: {
    onClearChange() {},
  },
};
</script>

<style lang="scss" scoped>
.container {
  width: 320px;
  overflow-y: scroll;
  height: calc(100vh - 55px);
  padding: 24px;
  box-shadow: 2px 0px 6px 0px rgba(0, 21, 41, 0.12);
  display: flex;
  flex-direction: column;
  .music-list {
    margin-top: 12px;
    .item-using {
      box-shadow: 0px 0px 8px 0px rgba(130, 144, 179, 0.5);
      border: 2px solid #5584ff;
    }
    .music-item {
      height: 54px;
      padding: 8px 12px 8px 8px;
      background: #f8fafc;
      border-radius: 4px;
      cursor: pointer;
      margin-top: 8px;
      box-sizing: border-box;
      display: flex;
      align-items: center;
      justify-content: space-between;
      &:hover {
        box-shadow: 0px 0px 8px 0px rgba(130, 144, 179, 0.5);
        border: 2px solid #5584ff;
      }
      .using {
        color: #5584ff;
        font-size: 12px;
      }
      .music-item-left {
        display: flex;
        .music-item-left-r {
          display: flex;
          flex-direction: column;
          justify-content: space-between;
        }
        .name {
          color: #333;
          font-size: 14px;
        }
        .music-left-icon {
          width: 38px;
          height: 38px;
          background-color: aquamarine;
          border-radius: 4px;
          margin-right: 8px;
        }
        .music-item-left-name {
          display: flex;
          align-items: center;
          .singer {
            color: #666666;
            font-size: 12px;
            margin-right: 4px;
          }
          .timer {
            color: #999999;
            font-size: 12px;
          }
        }
      }
    }
  }
  .add-btn {
    border: 1px solid #5584ff;
    display: flex;
    align-items: center;
    justify-content: center;
    padding-top: 5px;
    padding-bottom: 5px;
    border-radius: 4px;
    color: #5584ff;
    cursor: pointer;
    &:hover {
      opacity: 0.8;
    }
    .margin-r10 {
      margin-right: 10px;
    }
  }
}
</style>
