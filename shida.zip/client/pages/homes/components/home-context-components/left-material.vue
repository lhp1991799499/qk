<template>
  <div class="container" style="display: block">
    <div class="w100">
      <el-input
        placeholder="搜索素材"
        v-model="input"
        clearable
        prefix-icon="el-icon-search"
        clear="onClearChange"
      >
      </el-input>
    </div>
    <div>
      <el-tabs>
        <el-tab-pane v-for="item in list1" :label="item.label" :key="item.name">
        </el-tab-pane>
      </el-tabs>
      <scrollTabs />
      <template-container />
    </div>
  </div>
</template>

<script>
import scrollTabs from "../scroll-tabs.vue";
import templateContainer from "../template-container.vue";

export default {
  components: {
    scrollTabs,
    templateContainer,
  },
  data() {
    return {
      input: "",
      list1: [
        {
          label: "全部",
          name: "all",
        },
        {
          label: "热门",
          name: "hot",
        },
        {
          label: "全部",
          name: "al1l",
        },
        {
          label: "热门",
          name: "ho3t",
        },
      ],
    };
  },
  methods: {
    onClearChange() {
      console.log("12");
    },
  },
};
</script>

<style lang="scss" scoped>
.scroll-items {
  width: 272px;
  display: flex;
  overflow-x: scroll;
  overflow-y: hidden;
  &::-webkit-scrollbar {
    display: none;
  }
  .el-tabs__header {
    margin: 0;
  }
}
/deep/ .el-tabs__item {
  padding: 0 10px;
}
/deep/ .el-tabs__item.is-active {
  color: #5584ff;
}
/deep/ .el-tabs__active-bar {
  background-color: #5584ff;
}
/deep/ .el-tabs__header {
  margin: 0;
}
.scroll-item {
  height: 32px;
  padding: 8px;
  background: #f8fafc;
  border-radius: 4px;
  text-align: center;
  margin-left: 8px;
  writing-mode: horizontal-tb;
  &:first-child {
    margin-left: 0;
  }
}
.w100 {
  width: 100%;
}
.container {
  width: 320px;
  height: calc(100vh - 55px);
  padding: 24px;
  box-shadow: 2px 0px 6px 0px rgba(0, 21, 41, 0.12);
  display: flex;
  flex-direction: column;
}
</style>
