<template>
  <div class="container" style="display: block">
    <div class="add-btn" @click="handleClick(item)">
      <img
        class="margin-r10"
        src="../../../../../assets/image/icon/add.png"
      />添加文字
    </div>
  </div>
</template>

<script>
import scrollTabs from "../scroll-tabs.vue";
import templateContainer from "../template-container.vue";
import editor from "@client/mixins/editor.js";

export default {
  mixins: [editor],
  components: {
    scrollTabs,
    templateContainer,
  },
  data() {
    return {
      item: {
        elName: "qk-text",
        title: "文字",
        icon: "iconfont iconwenben",
        // 每个组件设置props来展示哪些显示哪些编辑项
        valueType: "", // 标识数据类型，用于表单组件
        defaultStyle: {
          height: 22,
        },
      },
    };
  },
  methods: {
    addFont() {},
  },
};
</script>

<style lang="scss" scoped>
.container {
  width: 320px;
  height: calc(100vh - 55px);
  padding: 24px;
  box-shadow: 2px 0px 6px 0px rgba(0, 21, 41, 0.12);
  display: flex;
  flex-direction: column;
  .add-btn {
    border: 1px solid #5584ff;
    display: flex;
    align-items: center;
    justify-content: center;
    padding-top: 5px;
    padding-bottom: 5px;
    border-radius: 4px;
    color: #5584ff;
    cursor: pointer;
    &:hover {
      opacity: 0.8;
    }
    .margin-r10 {
      margin-right: 10px;
    }
  }
}
</style>
