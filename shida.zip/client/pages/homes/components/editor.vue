<template>
  <div>
    <!--页面编辑区域-->
    <div class="editor-main" @contextmenu="onContextmenu">
      <div class="control-bar-wrapper">
        <controlBar
          :scale.sync="canvasConfig.scale"
          @import-psd-data="importPsdData"
          @cancel="cancelFn"
          @publish="publishFn"
          @save="saveFn"
        />
      </div>
      <editorPan :scale.sync="canvasConfig.scale" />
    </div>
  </div>
</template>

<script>
import controlBar from "../../../pages/editor/components/control-bar.vue";
import editorPan from '../../editor/components/editor-panel'
export default {
  components: {
    controlBar,
    editorPan
  },
  data() {
    return {
      canvasConfig: {
        scale: 1,
      },
    };
  },
  methods: {
    importPsdData() {},
    cancelFn() {},
    publishFn() {},
    saveFn() {},

    onContextmenu(e) {
      e.preventDefault();
      return false;
    },
  },
};
</script>

<style></style>
