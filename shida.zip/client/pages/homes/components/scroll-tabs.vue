<template>
  <div>
    <swiper class="swiper" :options="swiperOption">
      <swiper-slide v-for="item in list" :key="item.name">
        <div class="item">{{item.label}}</div>
      </swiper-slide>
      <!-- <div class="swiper-pagination" slot="pagination"></div> -->
      <!-- <div class="swiper-button-prev" slot="button-prev"></div>
      <div class="swiper-button-next" slot="button-next"></div> -->
    </swiper>
  </div>
</template>

<script>
import { Swiper, SwiperSlide } from "vue-awesome-swiper";
import "swiper/swiper-bundle.css";

export default {
  components: {
    Swiper,
    SwiperSlide,
  },
  data() {
    return {
      swiperOption: {
        slidesPerView: 5,
        spaceBetween: 8,
        slidesPerGroup: 5,
        loop: false,
        loopFillGroupWithBlank: true,
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
      },
      list: [
        {
          label: "全部",
          name: "all",
        },
        {
          label: "热门",
          name: "hot",
        },
        {
          label: "全部",
          name: "al1l",
        },
        {
          label: "热门",
          name: "ho3t",
        },
        {
          label: "全部",
          name: "all2",
        },
        {
          label: "热门",
          name: "hot1",
        },
        {
          label: "全部",
          name: "all23",
        },
        {
          label: "热门",
          name: "hot11",
        },
        {
          label: "全部",
          name: "a22ll2",
        },
        {
          label: "热门",
          name: "ho321t1",
        },
      ],
    };
  },
};
</script>

<style lang="scss" scoped>
.swiper {
  height: 50px;
  width: 100%;

  .swiper-slide {
    .item {
      padding: 6px 8px;
      background: #f8fafc;
      border-radius: 4px;
      cursor: pointer;
      font-size: 13px;
      &:hover{
        background: #e8f3ff;
      }
    }
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    // font-weight: bold;

  }
}
</style>
