<template>
  <div>
    <div class="font-setting">
      <div class="font-type">
        <el-select
          v-model="fontType"
          placeholder="请选择"
          value-key="id"
          @change="onchangeFont"
        >
          <el-option
            v-for="item in fontTypes"
            :key="item.id"
            :label="item.content.alias"
            :value="item"
          >
            <img :src="item.preview.url" alt="" />
          </el-option>
        </el-select>
      </div>
      <div class="font-size">
        <el-select
          v-model="fontSize"
          placeholder="请选择"
          value-key="value"
          @change="onchangeFontSize"
        >
          <el-option
            v-for="item in fontSizes"
            :key="item.value"
            :label="item.label"
            :value="item"
          >
          </el-option>
        </el-select>
      </div>
    </div>
    <div class="font-color">
      <div>文字颜色</div>
      <div class="color-box">
        <input
          class="picker-color"
          type="color"
          id="head"
          name="head"
          :value="activePage.commonStyle.color"
          @input="select"
        />
        <label for="head"></label>
      </div>
    </div>
    <div class="action">
      <div class="action-title mb24">操作</div>
      <div class="flex mb24">
        <div class="flex">
          <div class="image-box">
            <img src="../../../../../assets/image/icon/space.png" alt="" />
          </div>
          <div>
            <el-input-number
              v-model="num01"
              controls-position="right"
              @change="handleChange('jianju')"
              :min="1"
              :max="10"
              size="small"
            ></el-input-number>
          </div>
        </div>
        <div class="flex">
          <div class="image-box">
            <img src="../../../../../assets/image/icon/lineh.png" alt="" />
          </div>
          <div>
            <el-input-number
              v-model="num02"
              controls-position="right"
              @change="handleChange('hanggao')"
              :min="1"
              :max="10"
              size="small"
            ></el-input-number>
          </div>
        </div>
      </div>
      <div class="flex mb24">
        <div class="img-box" @click="toggleFontDirection">
          <el-tooltip content="文字横竖排列">
            <img src="../../../../../assets/image/icon/height.png" alt=""
          /></el-tooltip>
        </div>
        <div class="img-box w166 flex">
          <el-tooltip content="左对齐">
            <img
              @click="fontDirection('left')"
              src="../../../../../assets/image/icon/align_l.png"
              alt=""
          /></el-tooltip>
          <el-tooltip content="居中对齐">
            <img
              @click="fontDirection('center')"
              src="../../../../../assets/image/icon/align_c.png"
              alt=""
          /></el-tooltip>
          <el-tooltip content="右对齐">
            <img
              @click="fontDirection('right')"
              src="../../../../../assets/image/icon/align_r.png"
              alt=""
          /></el-tooltip>
        </div>
      </div>
      <div class="flex mb24">
        <div class="img-box flex width100">
          <img
            src="../../../../../assets/image/icon/bold.png"
            @click="handleChangeBold"
            alt=""
          />
          <img
            @click="fontItalic"
            src="../../../../../assets/image/icon/xie.png"
            alt=""
          />
          <img src="../../../../../assets/image/icon/xiahuaxian.png" alt="" />
          <img src="../../../../../assets/image/icon/zhonghuaxian.png" alt="" />
        </div>
      </div>
      <menu-edit-panel></menu-edit-panel>
      <div class="bind-title">绑定动态值</div>
      <div>
        <el-select
          class="bind-select-box"
          v-model="actionValue"
          placeholder="请选择"
          value-key="value"
        >
          <el-option
            v-for="item in actionValues"
            :key="item.value"
            :label="item.label"
            :value="item"
          >
          </el-option>
        </el-select>
      </div>
    </div>
  </div>
</template>

<script>
import fonts from "../../../../../fonts.json";
import editor from "@client/mixins/editor.js";
import menuEditPanel from "../edit-panel/common/menu-edit-panel.vue";
import { mapGetters } from "vuex";

export default {
  mixins: [editor],
  computed: {
    ...mapGetters(["activeElement", "activePage"]),
    fontSizeValue() {
      return this.activeElement.commonStyle.fontSize;
    },
  },
  mounted() {
   
    console.log(this.activeElement);
  },
  components: { menuEditPanel },
  data() {
    return {
      // commonStyle: this.activeElement.commonStyle,
      num01: 0,
      num02: 0,
      fontTypes: fonts,
      fontSizes: [
        {
          value: 14,
          label: "14px",
        },
        {
          value: 16,
          label: "16px",
        },
        {
          value: 18,
          label: "18px",
        },
        {
          value: 20,
          label: "20px",
        },
        {
          value: 40,
          label: "40px",
        },
        {
          value: 60,
          label: "60px",
        },
      ],
      actionValues: [
        {
          value: "单买价",
          label: "单买价",
        },
      ],
      actionValue: "",
      fontType: "",
      fontSize: {
        value: this.fontSizeValue || 16,
        label: this.fontSizeValue || 16 + "px",
      },
    };
  },
  methods: {
    fontItalic() {
      this.$store.dispatch("resetElementCommonStyle", {
        fontStyle:
          this.activeElement.commonStyle.fontStyle === "italic" ? "" : "italic",
      });
    },
    // 文字横竖排
    toggleFontDirection() {
      console.log(this.activeElement.commonStyle);
      this.$store.dispatch("resetElementCommonStyle", {
        writingMode:
          this.activeElement.commonStyle.writingMode === "vertical-lr"
            ? ""
            : "vertical-lr",
      });
    },
    // 文字左对齐
    fontDirection(e) {
      console.log(e);
      this.$store.dispatch("resetElementCommonStyle", {
        textAlign: e,
      });
    },

    // 字体加粗
    handleChangeBold() {
      this.$store.dispatch("elementCommand", "fontB");
    }, // 颜色选择
    select(e) {
      this.$store.dispatch("resetElementCommonStyle", {
        color: e.target.value,
      });
    },
    handleChange(value) {
      
      if(value=="jianju"){
        console.log(value);
        this.$store.dispatch("resetElementCommonStyle", {
          letterSpacing: this.num01,
        });
      }else{
        console.log(value);
        this.$store.dispatch("resetElementCommonStyle", {
          lineHeight: this.num02,
        });
      }
    },
    // 修改字体
    onchangeFont(item) {
      this.loadFont(item.name, item.content.ttf);
      // setTimeout(() => {
      this.$store.dispatch("changeFont", item.name);
      // }, 0);
    },
    // 修改字体大小
    onchangeFontSize(item) {
      console.log(item.value);
      this.$store.dispatch("resetElementCommonStyle", {
        fontSize: item.value,
        width:
          (this.activeElement.commonStyle.width /
            this.activeElement.commonStyle.fontSize) *
          item.value,
        height:
          (this.activeElement.commonStyle.height /
            this.activeElement.commonStyle.fontSize) *
          item.value,
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.w32 {
  width: 32px;
  font-weight: 400;
  color: #333333;
  font-size: 12px;
  margin-top: 4px;
  text-align: center;
}
.width100 {
  width: 100%;
}
.w166 {
  width: 166px;
}
.bg-gray {
  padding: 16px;
  background: #f6f7f9;
  cursor: pointer;
  &:hover {
    opacity: 0.8;
  }
}
.direction {
  flex-direction: column;
}
/deep/ .el-input-number--small {
  width: 80px;
}
// .img-layout {
//   width: 26px;
//   height: 26px;
//   cursor: pointer;
//   &:hover {
//     opacity: 0.8;
//   }
//   padding: 16px;
//   background: #f6f7f9;
// }
.flex {
  display: flex;
  justify-content: space-between;
  align-items: center;
  .image-box {
    width: 22px;
    height: 22px;
    margin-right: 8px;
  }
  .img-box {
    img {
      width: 26px;
      height: 26px;
      cursor: pointer;
      &:hover {
        opacity: 0.8;
      }
    }
    padding: 7px 16px;
    background: #f6f7f9;
  }
}
.action {
  margin-top: 24px;
  padding-left: 14px;
  padding-right: 14px;
  .action-title,
  .bind-title {
    font-weight: 600;
    color: #333333;
    margin-bottom: 16px;
  }
  .bind-select-box {
    width: 182px;
    margin-right: 8px;
  }
}
input[type="color"] {
  -webkit-appearance: none;
  border: none;
}
input[type="color"]::-webkit-color-swatch-wrapper {
  padding: 0;
}
input[type="color"]::-webkit-color-swatch {
  border: none;
}
.font-setting {
  padding-left: 14px;
  padding-right: 14px;
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  .font-type {
    margin-right: 12px;
    flex: 3;
  }
  .font-size {
    flex: 2;
  }
}
.font-color {
  margin-top: 24px;
  padding-left: 14px;
  padding-right: 14px;
  font-weight: 600;
  color: #333333;
  .color-box {
    border: 2px solid #f6f7f9;
    padding: 12px 12px 10px;
    margin-top: 16px;
  }
  .picker-color {
    border: none;
    padding: 0;
    width: 100%;
  }
}
.mb24 {
  margin-bottom: 24px !important;
}
</style>
