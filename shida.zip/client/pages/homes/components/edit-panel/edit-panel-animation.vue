<template>
  <div class="animation-panel-container">
    <!-- <div class="animation-panel">
      <div class="left-panel">
        <div class="title">进场动画</div>
        <div class="preview">预览</div>
      </div>
      <div class="cancel">取消动画</div>
    </div>

    <div class="animation-select">
      <div class="item">
        <div class="left">
          <div class="png">img</div>
          <div class="name">name</div>
        </div>
        <div>
          <el-button type="text">更换</el-button>
        </div>
      </div>
    </div> -->
    <!-- <div class="animation-strong">
      <div class="title">强调动画</div>
      <div class="panel">
        <div class="gray-img-add"></div>
        <div>添加动效</div>
      </div>
    </div>
    <div class="animation-strong">
      <div class="title">退场动画</div>
      <div class="panel">
        <div class="gray-img-add"></div>
        <div>添加动效</div>
      </div>
    </div> -->
    <add-animation
      v-for="item in usedItems"
      :key="item.title"
      :item="item"
    ></add-animation>
  </div>
</template>

<script>
import addAnimation from "./common/add-animation.vue";
import $bus from "@client/eventBus";
import runAnimations from "@client/common/js/runAnimations";
export default {
  components: {
    addAnimation,
  },
  mounted() {
    this.animatePlaying = false;
    $bus.$on("RUN_ANIMATIONS", (uuid, animations) => {
      console.log("ddd donghua");
      if (uuid !== this.uuid) {
        return;
      }
      // 正在执行的动画不允许插入新动画
      if (this.animatePlaying) return;
      let cssText = this.$el.style.cssText;
      this.animatePlaying = true;
      runAnimations(this.$el, animations, true, () => {
        this.$el.style.cssText = cssText;
        this.animatePlaying = false;
      });
    });
  },
  computed: {
    usedItems() {
      this.items.forEach((e) => {
        const animations =
          this.$store.getters.activeElement &&
          this.$store.getters.activeElement.animations;
        if (animations) {
          for (const i in animations) {
            if (Object.hasOwnProperty.call(animations, i)) {
              const element = animations[i];
              this.items.forEach((e) => {
                if (e.title === element.type.title) {
                  e.animations = element;
                }
              });
            }
          }
        }
      });
      return this.items;
    },
  },
  data() {
    return {
      animationTime: 0,
      animationDelay: 0,
      items: [
        {
          title: "进场动画",
          list: [
            { label: "渐显", value: "fadeIn" },
            { label: "向左进入", value: "fadeInLeft" },
            { label: "向右进入", value: "fadeInRight" },
            { label: "向上进入", value: "fadeInUp" },
            { label: "向下进入", value: "fadeInDown" },
            { label: "弹入", value: "bounceIn" },
          ],
        },
        {
          title: "强调动画",
          list: [
            { label: "向右退出", value: "fadeOutRight" },
            { label: "向上退出", value: "fadeOutUp" },
            { label: "向下退出", value: "fadeOutDown" },
            { label: "向左长距退出", value: "fadeOutLeftBig" },
            { label: "向右长距退出", value: "fadeOutRightBig" },
            { label: "向上长距退出", value: "fadeOutUpBig" },
          ],
        },
        { title: "退场动画", list: [{ name: "", nickName: "淡出" }] },
      ],
    };
  },
};
</script>

<style lang="scss" scoped>
.animation-panel-container {
  padding: 9px;
}
.animation-panel {
  padding: 9px;
  .left-panel {
    display: flex;
    align-items: center;
    .title {
      font-weight: 600;
      color: #333333;
      font-size: 14px;
    }
    .preview {
      color: #5584ff;
      font-size: 13px;
      margin-left: 16px;
    }
  }
  .cancel {
    font-weight: 500;
    font-size: 13px;
    color: #999999;
    cursor: pointer;
    &:hover {
      opacity: 0.8;
    }
  }
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
}
.animation-select {
  .item {
    padding: 8px 16px 8px;
    margin-bottom: 12px;
    display: flex;
    background: #f6f7f9;
    justify-content: space-between;
    .left {
      display: flex;
      align-items: center;
      .png {
        width: 52px;
        height: 52px;
      }
      .name {
        margin-left: 16px;
      }
    }
  }
}
.animation-strong {
  margin-top: 24px;
  border-radius: 4px;
  .title {
    font-weight: 600;
    color: #333333;
    font-size: 14px;
    margin-bottom: 8px;
  }
  .panel {
    padding: 8px;
    background: #f6f7f9;
    height: 68px;
    display: flex;
    align-items: center;
    font-size: 16px;
    color: #666;
    cursor: pointer;

    .gray-img-add {
      background: url("../../../../../assets/image/icon/gray-add.png") no-repeat
        center center;
      background-color: #fff;
      width: 52px;
      height: 52px;
      margin-right: 16px;
      border-radius: 4px;
      background-size: 16px;
    }
  }
}
</style>
