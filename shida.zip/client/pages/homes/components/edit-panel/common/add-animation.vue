<template>
  <div class="components-attr-animate-edit">
    <div class="title-content">
      <div class="title">
        {{ item.title }}
      </div>
      <div class="preview-content" v-if="animation.type.title">
        <div class="preview" @click="previewAnimation">预览</div>
        <div class="cancel-animation" @click="cancelAnimation">取消动画</div>
      </div>
    </div>
    <div class="animation-content">
      <el-popover
        width="300"
        height="500"
        trigger="click"
        v-model="popoverVisible"
        class="el-popover-box"
      >
        <div class="animation-strong" slot="reference">
          <div class="panel">
            <div class="gray-img-add">
              <img
                :width="animation.type.title ? '32px' : '16px'"
                :height="animation.type.title ? '32px' : '16px'"
                :src="
                  animation.type.title
                    ? require('../../../../../../assets/image/icon/animate-default.svg')
                    : require('../../../../../../assets/image/icon/gray-add.png')
                "
                alt=""
              />
            </div>
            <div>
              {{
                animation.type.title ? animation.type.animations : "添加动效"
              }}
            </div>
          </div>
        </div>
        <div class="context">
          <div class="title">{{ item.title }}</div>
          <div class="list-content">
            <div
              class="item-box"
              v-for="(item, i) in item.list"
              :key="i"
              @mouseover="hoverPreviewAnimate = item.value"
              @mouseleave="hoverPreviewAnimate = ''"
              @click="handleChooseAnimate(item)"
            >
              <div class="item">
                <img
                  :class="[
                    hoverPreviewAnimate === item.value &&
                      item.value + ' animated',
                  ]"
                  src="../../../../../../assets/image/icon/animate-default.svg"
                />
              </div>
              {{ item.label }}
            </div>
          </div>
        </div>
      </el-popover>
      <div v-if="animation.type.title" class="edit-animation-box">
        <div>
          <div style="color: #333; font-size: 14px">动画时长</div>
          <el-slider
            v-model="animation.delay"
            @change="delayChange"
            show-input
            :max="5"
          >
          </el-slider>
        </div>
        <div>
          <div style="color: #333; font-size: 14px">动画延时</div>
          <el-slider
            v-model="animation.duration"
            show-input
            @change="delayChange"
            :max="5"
          >
          </el-slider>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import $bus from "@client/eventBus";

export default {
  props: {
    item: {
      type: Object,
    },
  },
  computed: {
    ...mapGetters(["activeElement"]),
  },
  watch: {
    item() {
      this.item = this.item;
    },
  },
  data() {
    return {
      popoverVisible: false,
      hoverPreviewAnimate: "",
      reSelectAnimateIndex: undefined,
      animation: {
        delay: 0,
        duration: 0,
        type: {},
      },
    };
  },
  mounted() {
    this.getAnimation();
  },
  methods: {
    previewAnimation() {
      const animationData = this.activeElement.animations;
      console.log(animationData);
      $bus.$emit("RUN_ANIMATIONS", this.activeElement.uuid, animationData);
    },
    async getAnimation() {
      const animations =
        this.$store.getters.activeElement &&
        this.$store.getters.activeElement.animations;
      if (Object.keys(animations || {})) {
        for (const i in animations) {
          if (animations.hasOwnProperty.call(animations, i)) {
            const element = animations[i];
            if (this.item.title === element.type.title) {
              this.animation = element;
            }
          }
        }
        if (!Object.keys(animations || {}).includes(this.item.title)) {
          this.animation = {
            delay: 0,
            duration: 0,
            type: {},
          };
        }
      }
    },
    delayChange(e, type) {
      this.animation[type] = e;
    },
    /**
     * 选取animate
     * @param item
     */
    async handleChooseAnimate(item) {
      this.showAnimatePanel = false;
      let randomAnimate;
      if (item.value === "random") {
        console.log(item.value);
        // randomAnimate = this.createRandomAnimate(this.activeName);
        item = randomAnimate;
      }
      if (this.reSelectAnimateIndex === undefined) {
        await this.$store.dispatch("addElementAnimate", {
          title: this.item.title,
          animations: item.value,
        });
      } else {
        this.activeElement.animations[this.reSelectAnimateIndex].type =
          item.value;
        await this.$store.dispatch("addHistoryCache");
      }
      this.popoverVisible = false;

      this.getAnimation();
    },
    async cancelAnimation() {
      await this.$store.dispatch("deleteElementAnimate", this.item.title);
      await this.getAnimation();
    },
  },
};
</script>

<style lang="scss" scoped>
.animation-content {
  background: #f6f7f9;
  margin-top: 12px;
  padding-bottom: 1px;
}
.edit-animation-box {
  margin: 2px;
  background-color: #fff;
  padding: 12px;
}
.components-attr-animate-edit {
  position: relative;
}
.context {
  padding: 4px;
  .list-content {
    flex-wrap: wrap;
    display: flex;
    .item-box {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 50px;
      height: 50px;
      margin-right: 16px;
      margin-bottom: 8px;
      flex-direction: column;
      font-size: 12px;
      color: #666;
      cursor: pointer;
    }
    &:nth-child(4n) {
      margin-right: 0;
    }
    .item {
      margin-bottom: 4px;
    }
  }
}
.title-content {
  display: flex;
  align-items: center;
  width: 280px;
  .title {
    font-weight: 600;
    color: #333333;
    font-size: 16px;
    margin-bottom: 16px;
    margin-top: 16px;
  }
  .preview-content {
    display: flex;
    justify-content: space-between;
    width: 77%;
    .preview {
      color: #5584ff;
      font-size: 13px;
      margin-left: 8px;
      cursor: pointer;
    }
    .cancel-animation {
      color: #999999;
      font-size: 13px;
      cursor: pointer;
      margin-right: 8px;
    }
  }
}
.animation-strong {
  border-radius: 4px;
  .title {
    font-weight: 600;
    color: #333333;
    font-size: 14px;
    margin-bottom: 8px;
  }
  .panel {
    padding: 8px;
    background: #f6f7f9;
    height: 68px;
    display: flex;
    align-items: center;
    font-size: 16px;
    color: #666;
    cursor: pointer;
    &:hover {
      background: #ebeced;
    }
    .gray-img-add {
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: #fff;
      width: 52px;
      height: 52px;
      margin-right: 16px;
      border-radius: 4px;
      background-size: 16px;
    }
  }
}
.animation-strong {
  border-radius: 4px;
  .title {
    font-weight: 600;
    color: #333333;
    font-size: 14px;
    margin-bottom: 8px;
  }
  .panel {
    padding: 8px;
    background: #f6f7f9;
    height: 68px;
    display: flex;
    align-items: center;
    font-size: 16px;
    color: #666;
    cursor: pointer;

    .gray-img-add {
      background-color: #fff;
      width: 52px;
      height: 52px;
      margin-right: 16px;
      border-radius: 4px;
      background-size: 16px;
    }
  }
}
</style>
