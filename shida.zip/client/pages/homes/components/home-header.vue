<template>
  <div class="header">
    <div class="left-item">
      <div style="width: 320px">
        <img
          class="icon mr32 ml56"
          @click="editorUndo"
          :src="
            canUndo
              ? require('../../../../assets/image/icon/up.png')
              : require('../../../../assets/image/icon/up0.png')
          "
        />
        <img
          class="icon"
          @click="editorRedo"
          :src="
            canRedo
              ? require('../../../../assets/image/icon/cancle.png')
              : require('../../../../assets/image/icon/cancle0.png')
          "
        />
      </div>

      <div class="main-title">
        <img class="mr3" src="../../../../assets/image/icon/point.png" />
        <div class="sub">标题</div>
        <el-input
          label="标题"
          placeholder="请输入标题"
          width="305px"
          size="small"
        ></el-input>
      </div>
    </div>
    <el-button type="primary" class="save" @click="publishFn"
      >保存并上传</el-button
    >
  </div>
</template>

<script>
import { mapActions, mapGetters } from "vuex";
export default {
  data() {
    return {
      historyIndex: -1,
      widgetHistory: [], // 记录历史记录变动的
      widgetHistoryBack: [], //记录历史记录返回
    };
  },
  computed: {
    ...mapGetters(["canUndo", "canRedo"]),
    canClickPrev() {
      // 是否能点击上一步
      return this.historyIndex > -1;
    },
    canClickNext() {
      return (
        this.historyIndex < this.widgetHistory.length - 1 &&
        this.widgetHistory.length > 0
      );
    },
  },
  methods: {
    ...mapActions(["editorUndo", "editorRedo"]),
    publishFn() {},
  },
};
</script>

<style lang="scss" scoped>
.mr32 {
  margin-right: 32px;
}
.ml56 {
  margin-left: 56px;
}
.icon {
  width: 27px;
  height: 27px;
  cursor: pointer;
}
.left-item {
  display: flex;
}
.header {
  height: 55px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  box-shadow: 0px 2px 6px 0px rgba(0, 21, 41, 0.12);
  padding-left: 24px;
  padding-right: 24px;
}
.save {
  color: #ffffff;
  // padding: 5px 16px;
  background: #5584ff;
  font-size: 13px;
  border: 0;
}
.main-title {
  display: flex;
  justify-content: center;
  align-items: center;
  .sub {
    font-weight: bolder;
    width: 42px;
    font-size: 13px;
    height: 20px;
    line-height: 20px;
  }
  .mr3 {
    margin-right: 3px;
    margin-top: -2px;
  }
}
</style>
