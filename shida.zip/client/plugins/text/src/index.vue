<!--test.vue-->
<template>
  <div class="qk-text" contenteditable="true">
    {{ showText }}
  </div>
</template>

<script>
import VueDragResizeRotate from "@gausszhou/vue-drag-resize-rotate";
export default {
  name: "QkText", // 这个名字很重要，它就是未来的标签名<qk-text></qk-text>
  components: {
    VueDragResizeRotate,
  },
  props: {
    text: {
      type: String,
      default: "这是一段文字",
    },
    font: {
      type: String,
      default: "wryh",
    },
  },
  data() {
    return {
      defaultStyle: {
        height: 40,
      },
      showText: this.text,
      editing: false,
    };
  },
  methods: {
    resizing(x, y, w, h) {
      console.log(x, y, w, h);
    },
    rotating(angle) {
      console.log(angle);
    },
  },
};
</script>

<style lang="scss" scoped>
div[contenteditable] {
  outline: none;
}
</style>
