<template>

</template>

<script>
	export default {
		name: "yiqixiu"
	}
</script>

<style scoped>

</style>
